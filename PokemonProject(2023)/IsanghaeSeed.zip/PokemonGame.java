public class PokemonGame {
    public static void main(String[] args) {
        Script s1= new Script();
        s1.ownerName_Script();
        s1.PokemonChoice_Script();
        s1.closing_doctorO_Script();
        Menu.menu();
    }
}