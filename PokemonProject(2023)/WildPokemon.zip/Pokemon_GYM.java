interface Pokemon_GYM {
    String[] gymName = {"태간 체육관","성용 태육관"};
    String[] gymKingName = {"김태간","차성용"};
    String[] gymPokemon = {"cpp","수학수학"};
    int[] gymPokemonExp = {50,45};

    static void info(){
        System.out.println(gymName[0]);
    }
}

